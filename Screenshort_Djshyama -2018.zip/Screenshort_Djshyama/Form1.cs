﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Screenshort_Djshyama
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The image of the whole screen.
        private Bitmap ScreenBm, VisibleBm;

        // The area we are selecting.
        private int X0, Y0, X1, Y1;

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void selectAreaToolStripMenuItem_Click(object sender, EventArgs e)
        {  
            // Get the whole screen's image.
            ScreenBm = GetScreenImage();

            // Display a copy.
            VisibleBm = (Bitmap)ScreenBm.Clone();

            // Display it.
            this.BackgroundImage = VisibleBm;
            this.Location = new Point(0, 0);
            this.ClientSize = VisibleBm.Size;
            this.MouseDown += Form1_MouseDown;
            this.Show();

        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            X0 = e.X;
            Y0 = e.Y;
            X1 = e.X;
            Y1 = e.Y;

            this.MouseDown -= Form1_MouseDown;
            this.MouseMove += Form1_MouseMove;
            this.MouseUp += Form1_MouseUp;
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            this.Visible = false;
            this.MouseMove -= Form1_MouseMove;
            this.MouseUp -= Form1_MouseUp;

            // Save the selected part of the image.

           
            int wid = Math.Abs(X1 - X0);
            int hgt = Math.Abs(Y1 - Y0);
            Rectangle dest_rect = new Rectangle(0, 0, wid, hgt);
            Rectangle source_rect = new Rectangle(
            Math.Min(X0, X1),
                Math.Min(Y0, Y1),
                Math.Abs(X1 - X0),
                Math.Abs(Y1 - Y0));
            try
            {
                using (Bitmap selection = new Bitmap(wid, hgt))
                {
                    // Copy the selected area.
                    using (Graphics gr = Graphics.FromImage(selection))
                    {
                        gr.DrawImage(ScreenBm, dest_rect, source_rect, GraphicsUnit.Pixel);
                    }

                    // Save the selected area.
                    SavePicture(selection);
                }

            }
            catch (Exception)
            {

                MessageBox.Show("Please Choose your Select Area.",
                             "Djshyama Notice : - ",
                             MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
                
           
           

            // Dispose of the other bitmaps.
            this.BackgroundImage = null;
            ScreenBm.Dispose();
            VisibleBm.Dispose();
            ScreenBm = null;
            VisibleBm = null;
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            X1 = e.X;
            Y1 = e.Y;

            using (Graphics gr = Graphics.FromImage(VisibleBm))
            {
                // Copy the original image.
                gr.DrawImage(ScreenBm, 0, 0);

                // Draw the selected area.
                Rectangle rect = new Rectangle(
                    Math.Min(X0, X1),
                    Math.Min(Y0, Y1),
                    Math.Abs(X1 - X0),
                    Math.Abs(Y1 - Y0));
                gr.DrawRectangle(Pens.Red, rect);
            }

            this.Refresh();
        }

        private void sfdScreenImage_FileOk(object sender, CancelEventArgs e) { }
       
        private void fullScreenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (Bitmap bm = GetScreenImage())
            {
                // Save it.
                SavePicture(bm);
            }
        }

        private void SavePicture(Bitmap bm)
        {

            sfdScreenImage.Filter = "BMP FILE (*.bmp)|*.bmp|JPG FILE (*.jpg)|*.jpg|GIF FILE (*.gif)|*.gif|TIFF FILE  (*.tiff)|*.tiff|PNG FILE (*.png)|*.png ";
            // Let the user pick a file to hold the image.
            if (sfdScreenImage.ShowDialog() == DialogResult.OK)
            {
                // Save the bitmap in the selected file.
                string filename = sfdScreenImage.FileName;
                FileInfo file_info = new FileInfo(filename);
                switch (file_info.Extension.ToLower())
                {
                    case ".png":
                        bm.Save(filename, ImageFormat.Png);
                        break;
                    case ".gif":
                        bm.Save(filename, ImageFormat.Gif);
                        break;
                    case ".jpg":
                    case ".jpeg":
                        bm.Save(filename, ImageFormat.Jpeg);
                        break;
                    case ".bmp":
                        bm.Save(filename, ImageFormat.Bmp);
                        break;
                    default:
                        MessageBox.Show("Unknown file type " +
                            file_info.Extension, "Unknown Extension",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;

                        

                }

               
            }
        }

        private Bitmap GetScreenImage()
        {
              Bitmap bm = new Bitmap
              (
              Screen.PrimaryScreen.Bounds.Width,
              Screen.PrimaryScreen.Bounds.Height,
              PixelFormat.Format24bppRgb
              );

                // Copy the image into the bitmap.
                using (Graphics gr = Graphics.FromImage(bm))
                {
                    gr.CopyFromScreen(
                        Screen.PrimaryScreen.Bounds.X,
                        Screen.PrimaryScreen.Bounds.Y,
                        0, 0,
                        Screen.PrimaryScreen.Bounds.Size,
                        CopyPixelOperation.SourceCopy);
                }

                // Return the result.
                return bm;
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.TopMost = true;
            this.ShowInTaskbar = false;
            this.Visible = false;
            this.Cursor = Cursors.Hand;
            this.contextMenuStrip1.BackColor = Color.WhiteSmoke;
            this.contextMenuStrip1.ForeColor = Color.Black;
          
        }

       
    }
}
